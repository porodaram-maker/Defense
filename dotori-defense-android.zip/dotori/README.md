# 도토리 사수대 - 안드로이드 프로젝트

게임 전체는 `app/src/main/assets/index.html` 파일 하나다. 나머지는 이걸 전체화면 앱으로 감싸는 껍데기.

## 방법 1. GitHub로 APK 받기 (설치할 것 없음)

1. GitHub에서 새 저장소를 만든다 (비공개 가능).
2. 이 폴더 안의 내용을 전부 올린다. `.github` 폴더도 꼭 같이 올라가야 한다.
   - 웹에서 올릴 땐 "uploading an existing file"로 폴더째 끌어다 놓으면 된다.
3. 저장소의 **Actions** 탭으로 가면 "APK 빌드"가 자동으로 돌아간다 (5분 안팎).
4. 끝나면 해당 실행을 눌러 맨 아래 **Artifacts**에서 `dotori-defense-apk`를 받는다.
5. 압축을 풀고 `app-debug.apk`를 폰으로 옮겨 설치한다.
   - "출처를 알 수 없는 앱 설치"를 허용하라는 창이 뜨면 허용.

## 방법 2. Android Studio로 빌드

1. Android Studio에서 이 폴더를 연다 (Open).
2. Gradle 동기화가 끝날 때까지 기다린다 (처음엔 몇 분 걸림).
3. 메뉴 **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. 완료 알림의 **locate**를 누르면 `app-debug.apk`가 있다.
   - 폰을 USB로 연결했다면 초록색 실행 버튼으로 바로 설치된다.

## 게임을 새 버전으로 바꾸려면

`app/src/main/assets/index.html`을 새 게임 파일로 덮어쓰고, `app/build.gradle`의 `versionCode`를 1 올린 뒤 다시 빌드한다.
테스트 버전(전부 해금)을 앱으로 만들고 싶으면 테스트 html을 `index.html` 이름으로 넣으면 된다.

## 플레이스토어에 올리려면

디버그 APK는 개인 설치용이다. 스토어용은 서명된 릴리스 빌드(AAB)가 필요하다.
1. 키스토어를 만든다: `keytool -genkey -v -keystore dotori.jks -keyalg RSA -keysize 2048 -validity 10000 -alias dotori`
2. 환경변수 `DOTORI_KEYSTORE`(파일 경로), `DOTORI_KEYSTORE_PASSWORD`, `DOTORI_KEY_ALIAS`, `DOTORI_KEY_PASSWORD`를 설정하고
   `gradle bundleRelease`를 실행하면 `app/build/outputs/bundle/release/app-release.aab`가 나온다.
3. 키스토어 파일과 비밀번호는 절대 잃어버리면 안 된다 (업데이트를 못 올리게 됨).

## 참고

- 세이브(코인, 잣, 강화, 덱)는 폰 안에 저장된다. 앱을 지우면 같이 지워진다.
- 공유 랭킹은 claude.ai 링크에서만 동작한다. 앱에서는 기기 안 기록으로 랭킹이 표시된다.
- 인터넷이 있으면 게임 전용 글꼴을 받아오고, 없으면 기본 글꼴로 나온다.
- `store_icon_512.png`는 스토어 등록용 아이콘이다.
